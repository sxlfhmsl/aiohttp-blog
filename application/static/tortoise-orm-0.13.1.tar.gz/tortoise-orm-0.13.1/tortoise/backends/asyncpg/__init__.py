from .client import AsyncpgDBClient

client_class = AsyncpgDBClient
